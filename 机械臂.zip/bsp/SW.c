#include "SW.h" 

void SW_Init(void)    
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);//ʹ��GPIOFʱ��
	
	/****��ʼ��GPIOF0~7****/
	
	GPIO_InitTypeDef  GPIO_InitStructure;	
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 |
			GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 ;	//SW0~7��ӦGPIOF0~7										
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;				//����ģʽ
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;		    //����
	
	GPIO_Init(GPIOF, &GPIO_InitStructure);				    	//��ʼ��GPIOF
}
