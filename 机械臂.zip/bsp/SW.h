#ifndef __SW_H
#define __SW_H
#include "sys.h"

//����SW�˿�
#define SW0	 	GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_0)		
#define SW1		GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_1)		
#define SW2		GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_2)		
#define SW3     GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_3)
#define SW4 	GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_4)
#define SW5		GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_5)
#define SW6		GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_6)
#define SW7     GPIO_ReadInputDataBit(GPIOF,GPIO_Pin_7)

void SW_Init(void);	//���忪��SW��ʼ������

#endif  
